
---

## 🔟 `ai/ApiClient.kt`

```kotlin
package com.wda.idibotultimate.keecc.ai

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object ApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun chat(
        provider: String,
        apiKey: String,
        history: List<Pair<String, String>>,
        userMsg: String
    ): String = withContext(Dispatchers.IO) {
        try {
            if (apiKey.isBlank()) return@withContext AIBrain.localFallback(userMsg)
            when (provider.lowercase()) {
                "gemini" -> gemini(apiKey, history, userMsg)
                else -> openai(apiKey, history, userMsg)
            }
        } catch (e: Exception) {
            "⚠️ Error koneksi: ${e.message}\n\nFallback mode:\n${AIBrain.localFallback(userMsg)}"
        }
    }

    private fun openai(key: String, history: List<Pair<String, String>>, userMsg: String): String {
        val root = JsonObject().apply { addProperty("model", "gpt-4o-mini") }
        val msgs = JsonArray().apply {
            add(JsonObject().apply {
                addProperty("role", "system")
                addProperty("content", AIBrain.SYSTEM_PROMPT)
            })
            history.forEach { (r, t) ->
                add(JsonObject().apply {
                    addProperty("role", if (r == "user") "user" else "assistant")
                    addProperty("content", t)
                })
            }
            add(JsonObject().apply {
                addProperty("role", "user")
                addProperty("content", userMsg)
            })
        }
        root.add("messages", msgs)

        val body = root.toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .post(body).build()

        client.newCall(req).execute().use { resp ->
            val s = resp.body?.string() ?: ""
            val json = JsonParser.parseString(s).asJsonObject
            if (json.has("error"))
                return json.getAsJsonObject("error").get("message").asString
            return json.getAsJsonArray("choices")[0].asJsonObject
                .getAsJsonObject("message").get("content").asString
        }
    }

    private fun gemini(key: String, history: List<Pair<String, String>>, userMsg: String): String {
        val root = JsonObject()

        val sys = JsonObject().apply {
            add("parts", JsonArray().apply {
                add(JsonObject().apply { addProperty("text", AIBrain.SYSTEM_PROMPT) })
            })
        }
        root.add("systemInstruction", sys)

        val contents = JsonArray().apply {
            history.forEach { (r, t) ->
                add(JsonObject().apply {
                    addProperty("role", if (r == "user") "user" else "model")
                    add("parts", JsonArray().apply {
                        add(JsonObject().apply { addProperty("text", t) })
                    })
                })
            }
            add(JsonObject().apply {
                addProperty("role", "user")
                add("parts", JsonArray().apply {
                    add(JsonObject().apply { addProperty("text", userMsg) })
                })
            })
        }
        root.add("contents", contents)

        val body = root.toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                "gemini-1.5-flash:generateContent?key=$key"

        val req = Request.Builder().url(url).post(body).build()
        client.newCall(req).execute().use { resp ->
            val s = resp.body?.string() ?: ""
            val json = JsonParser.parseString(s).asJsonObject
            if (json.has("error"))
                return json.getAsJsonObject("error").get("message").asString
            return json.getAsJsonArray("candidates")[0].asJsonObject
                .getAsJsonObject("content").getAsJsonArray("parts")[0].asJsonObject
                .get("text").asString
        }
    }
}