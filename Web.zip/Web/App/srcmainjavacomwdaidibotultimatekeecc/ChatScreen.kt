package com.wda.idibotultimate.keecc.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.wda.idibotultimate.keecc.ai.AIBrain
import com.wda.idibotultimate.keecc.ai.ApiClient
import com.wda.idibotultimate.keecc.data.Prefs
import com.wda.idibotultimate.keecc.ui.theme.*
import kotlinx.coroutines.launch
import java.util.Locale

data class Msg(val role: String, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(onOpenEditor: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var messages by remember { mutableStateOf(loadHistory(prefs)) }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull().orEmpty()
            if (text.isNotBlank()) input = (input + " " + text).trim()
        }
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        input = ""
        messages = messages + Msg("user", text)
        loading = true
        saveHistory(prefs, messages)

        scope.launch {
            val history = messages.dropLast(1).map { it.role to it.text }
            val reply = ApiClient.chat(
                prefs.provider,
                if (prefs.provider == "gemini") prefs.geminiKey else prefs.openAiKey,
                history, text
            )
            messages = messages + Msg("bot", reply)
            loading = false
            saveHistory(prefs, messages)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("IDIBOT ULTIMATE", color = NeonGreen,
                            fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("WDA KEECC · AI 10.000 Fungsi",
                            color = WhiteSoft.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark),
                actions = {
                    IconButton(onClick = onOpenEditor) {
                        Icon(Icons.Default.Code, "Editor", tint = NeonGreen)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, "Setting", tint = NeonGreen)
                    }
                }
            )
        },
        containerColor = BlackBg
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { m -> ChatBubble(m) }
                if (loading) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                Modifier.size(18.dp), color = NeonGreen, strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("IDIBOT mikir sat-set...",
                                color = NeonGreen, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Input bar
            Surface(color = SurfaceDark, tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Tanya apa aja kak...", color = WhiteSoft.copy(0.5f)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = NeonGreen.copy(0.4f),
                            focusedTextColor = WhiteSoft,
                            unfocusedTextColor = WhiteSoft
                        ),
                        maxLines = 4,
                        shape = RoundedCornerShape(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))

                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicara kak...")
                        }
                        micLauncher.launch(intent)
                    }) { Icon(Icons.Default.Mic, "MIC", tint = NeonGreen) }

                    IconButton(onClick = {
                        // Upload LOG (placeholder - bisa diganti file picker)
                        messages = messages + Msg("user", "[UPLOAD LOG] Kirim file log/error ke IDIBOT")
                        loading = true
                        scope.launch {
                            kotlinx.coroutines.delay(500)
                            messages = messages + Msg("bot",
                                "Log diterima kak! Kirim isi log-nya biar aku analisa sat-set 🔍")
                            loading = false
                        }
                    }) { Icon(Icons.Default.UploadFile, "UPLOAD LOG", tint = NeonGreen) }

                    IconButton(onClick = { send() }, enabled = !loading) {
                        Icon(Icons.Default.Send, "KIRIM",
                            tint = if (loading) NeonGreen.copy(0.4f) else NeonGreen)
                    }
                }
            }
        }
    }

    if (showSettings) {
        ApiKeyDialog(prefs, onClose = { showSettings = false })
    }

    // Auto greeting first time
    LaunchedEffect(Unit) {
        if (messages.isEmpty()) {
            messages = listOf(Msg("bot", AIBrain.GREETING))
            saveHistory(prefs, messages)
        }
    }
}

@Composable
private fun ChatBubble(m: Msg) {
    val isUser = m.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (isUser) NeonGreen.copy(0.15f) else SurfaceVariant,
            shape = RoundedCornerShape(
                topStart = 16.dp, topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(Modifier.padding(10.dp)) {
                Text(
                    if (isUser) "Kamu" else "IDIBOT",
                    color = NeonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(3.dp))
                Text(m.text, color = WhiteSoft, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun ApiKeyDialog(prefs: Prefs, onClose: () -> Unit) {
    var provider by remember { mutableStateOf(prefs.provider) }
    var openAi by remember { mutableStateOf(prefs.openAiKey) }
    var gemini by remember { mutableStateOf(prefs.geminiKey) }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = SurfaceDark,
        title = { Text("⚙️ Otak AI IDIBOT", color = NeonGreen) },
        text = {
            Column {
                Text("Provider", color = WhiteSoft, fontSize = 12.sp)
                Row {
                    FilterChip(
                        selected = provider == "gemini",
                        onClick = { provider = "gemini" },
                        label = { Text("Gemini") }
                    )
                    Spacer(Modifier.width(8.dp))
                    FilterChip(
                        selected = provider == "openai",
                        onClick = { provider = "openai" },
                        label = { Text("OpenAI") }
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = gemini, onValueChange = { gemini = it },
                    label = { Text("Gemini API Key") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        focusedTextColor = WhiteSoft,
                        unfocusedTextColor = WhiteSoft,
                        focusedLabelColor = NeonGreen
                    )
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = openAi, onValueChange = { openAi = it },
                    label = { Text("OpenAI API Key") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        focusedTextColor = WhiteSoft,
                        unfocusedTextColor = WhiteSoft,
                        focusedLabelColor = NeonGreen
                    )
                )
                Spacer(Modifier.height(6.dp))
                Text("Tanpa key, IDIBOT pakai mode offline basic.",
                    color = WhiteSoft.copy(0.5f), fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                prefs.provider = provider
                prefs.openAiKey = openAi
                prefs.geminiKey = gemini
                onClose()
            }) { Text("SIMPAN", color = NeonGreen) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("BATAL", color = WhiteSoft) }
        }
    )
}

private fun loadHistory(prefs: Prefs): List<Msg> = try {
    val type = object : TypeToken<List<Msg>>() {}.type
    Gson().fromJson<List<Msg>>(prefs.historyJson, type) ?: emptyList()
} catch (_: Exception) { emptyList() }

private fun saveHistory(prefs: Prefs, list: List<Msg>) {
    prefs.historyJson = Gson().toJson(list)
}