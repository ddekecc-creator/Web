package com.wda.idibotultimate.keecc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.wda.idibotultimate.keecc.ui.ChatScreen
import com.wda.idibotultimate.keecc.ui.CodeEditorScreen
import com.wda.idibotultimate.keecc.ui.SplashScreen
import com.wda.idibotultimate.keecc.ui.theme.IDIBOTTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot() {
    IDIBOTTheme {
        val nav = rememberNavController()
        NavHost(nav, startDestination = "splash") {
            composable("splash") {
                SplashScreen { nav.navigate("home") { popUpTo("splash") { inclusive = true } } }
            }
            composable("home") {
                ChatScreen(onOpenEditor = { nav.navigate("editor") })
            }
            composable("editor") {
                CodeEditorScreen(onBack = { nav.popBackStack() })
            }
        }
    }
}