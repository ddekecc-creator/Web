package com.wda.idibotultimate.keecc.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonGreen      = Color(0xFF00FF9C)
val NeonGreenDim   = Color(0xFF00C97A)
val BlackBg        = Color(0xFF000000)
val SurfaceDark    = Color(0xFF0A0F0D)
val SurfaceVariant = Color(0xFF10231C)
val WhiteSoft      = Color(0xFFEFFFF8)

private val Colors = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Color.Black,
    secondary = NeonGreenDim,
    background = BlackBg,
    onBackground = WhiteSoft,
    surface = SurfaceDark,
    onSurface = WhiteSoft,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = WhiteSoft
)

@Composable
fun IDIBOTTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}