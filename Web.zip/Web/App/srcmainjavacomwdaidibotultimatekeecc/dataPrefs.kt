package com.wda.idibotultimate.keecc.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("idibot_wda_keecc", Context.MODE_PRIVATE)

    var provider: String
        get() = sp.getString("provider", "gemini") ?: "gemini"
        set(v) = sp.edit().putString("provider", v).apply()

    var openAiKey: String
        get() = sp.getString("openai_key", "") ?: ""
        set(v) = sp.edit().putString("openai_key", v).apply()

    var geminiKey: String
        get() = sp.getString("gemini_key", "") ?: ""
        set(v) = sp.edit().putString("gemini_key", v).apply()

    var historyJson: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) = sp.edit().putString("history", v).apply()
}