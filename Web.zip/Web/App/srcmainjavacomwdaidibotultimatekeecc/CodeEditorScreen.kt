package com.wda.idibotultimate.keecc.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import android.webkit.WebViewClient
import com.wda.idibotultimate.keecc.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private val SAMPLE = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>IDIBOT Store</title>
  <style>
    body{background:#000;color:#0f9;font-family:sans-serif;text-align:center;padding:40px}
    h1{text-shadow:0 0 20px #0f9}
  </style>
</head>
<body>
  <h1>IDIBOT ULTIMATE</h1>
  <p>WDA KEECC siap jualan 24 jam 🔥</p>
</body>
</html>
""".trimIndent()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeEditorScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf(SAMPLE) }
    var showWebView by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = NeonGreen)
                    }
                },
                title = { Text("Code Editor", color = NeonGreen) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        containerColor = BlackBg
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(8.dp)) {

            // Editor
            Surface(
                color = Color(0xFF050A08),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                Box(Modifier.padding(10.dp)) {
                    BasicTextField(
                        value = code,
                        onValueChange = { code = it },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = WhiteSoft,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        ),
                        visualTransformation = SyntaxHighlight()
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Toolbar aksi
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ActionBtn("COPY", Icons.Default.ContentCopy) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("code", code))
                    toast(ctx, "Kode dicopy kak ✅")
                }
                ActionBtn("RUN", Icons.Default.PlayArrow) {
                    if (code.contains("<html", true) || code.contains("<body", true)) {
                        showWebView = true
                    } else {
                        toast(ctx, "Bahasa non-HTML belum bisa run lokal. Kirim ke IDIBOT untuk di-review 🚀")
                    }
                }
                ActionBtn("SAVE ZIP", Icons.Default.FolderZip) {
                    scope.launch {
                        val f = saveZip(ctx, code)
                        toast(ctx, "ZIP tersimpan: ${f?.name ?: "gagal"}")
                    }
                }
                ActionBtn("EXPORT APK", Icons.Default.Android) {
                    toast(ctx, "Export APK: Build > Build Bundle(s)/APK(s) > Build APK(s) di Android Studio 🔧")
                }
            }
        }
    }

    if (showWebView) {
        AlertDialog(
            onDismissRequest = { showWebView = false },
            containerColor = SurfaceDark,
            confirmButton = {
                TextButton(onClick = { showWebView = false }) {
                    Text("TUTUP", color = NeonGreen)
                }
            },
            title = { Text("Preview Web", color = NeonGreen) },
            text = {
                Box(Modifier.fillMaxWidth().height(400.dp)) {
                    AndroidView(factory = { c ->
                        WebView(c).apply {
                            webViewClient = WebViewClient()
                            settings.javaScriptEnabled = true
                            loadDataWithBaseURL(null, code, "text/html", "utf-8", null)
                        }
                    })
                }
            }
        )
    }
}

@Composable
private fun ActionBtn(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                      onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = SurfaceVariant,
            contentColor = NeonGreen
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Icon(icon, null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 12.sp)
    }
}

private fun toast(ctx: Context, s: String) =
    Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

private suspend fun saveZip(ctx: Context, code: String): File? = withContext(Dispatchers.IO) {
    try {
        val dir = File(ctx.getExternalFilesDir(null), "idibot_projects")
        if (!dir.exists()) dir.mkdirs()
        val zip = File(dir, "idibot_${System.currentTimeMillis()}.zip")
        ZipOutputStream(zip.outputStream()).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(content.toByteArray())
                z.closeEntry()
            }
            put("index.html", code)
            put("README.md",
                "# IDIBOT ULTIMATE STORE WDA KEECC\n" +
                "Dev: IDI STORE WDA KEECC Cirebon\n" +
                "AI 10.000 Fungsi\n")
            put("package-info.json",
                "{\"app\":\"IDIBOT ULTIMATE\",\"dev\":\"IDI STORE WDA KEECC\"}")
        }
        zip
    } catch (_: Exception) { null }
}

/** Syntax highlight sederhana untuk VS Code look */
private class SyntaxHighlight : VisualTransformation {
    private val tokenRegex = Regex(
        "(//[^\\n]*|#[^\\n]*|/\\*[\\s\\S]*?\\*/)" +              // komentar
        "|(\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*')" +    // string
        "|\\b(fun|val|var|class|object|interface|if|else|for|while|when|return|" +
        "import|package|def|function|const|let|async|await|try|catch|throw|" +
        "public|private|protected|static|void|int|String|boolean|new|this|" +
        "true|false|null|undefined)\\b" +
        "|\\b(\\d+)\\b"                                          // angka
    )

    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        val out = buildAnnotatedString {
            var last = 0
            for (m in tokenRegex.findAll(src)) {
                if (m.range.first > last) append(src.substring(last, m.range.first))
                val t = m.value
                val color = when {
                    t.startsWith("//") || t.startsWith("#") || t.startsWith("/*") -> Color(0xFF6A9955)
                    t.startsWith("\"") || t.startsWith("'") -> Color(0xFFCE9178)
                    t.all { it.isDigit() } -> Color(0xFFB5CEA8)
                    else -> Color(0xFF00FF9C)
                }
                withStyle(SpanStyle(color = color)) { append(t) }
                last = m.range.last + 1
            }
            if (last < src.length) append(src.substring(last))
        }
        return TransformedText(out, OffsetMapping.Identity)
    }
}