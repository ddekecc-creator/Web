package com.wda.idibotultimate.keecc.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wda.idibotultimate.keecc.ui.theme.BlackBg
import com.wda.idibotultimate.keecc.ui.theme.NeonGreen
import com.wda.idibotultimate.keecc.ui.theme.WhiteSoft
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var progress by remember { mutableIntStateOf(0) }
    val pulse = rememberInfiniteTransition().animateFloat(
        initialValue = 0.85f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse)
    )

    LaunchedEffect(Unit) {
        while (progress < 40) {
            delay(70)
            progress++
        }
        delay(400)
        onDone()
    }

    Box(
        Modifier.fillMaxSize().background(BlackBg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            RobotKEECC(pulse.value)

            Spacer(Modifier.height(28.dp))

            Text(
                "IDIBOT ULTIMATE",
                color = NeonGreen, fontSize = 24.sp, fontWeight = FontWeight.Bold
            )
            Text("STORE WDA KEECC", color = WhiteSoft, fontSize = 16.sp)
            Text("AI 10.000 Fungsi", color = NeonGreen.copy(alpha = 0.7f), fontSize = 13.sp)

            Spacer(Modifier.height(30.dp))

            LinearProgressIndicator(
                progress = { progress / 40f },
                modifier = Modifier.width(240.dp).height(6.dp),
                color = NeonGreen,
                trackColor = Color(0xFF10231C)
            )

            Spacer(Modifier.height(10.dp))
            Text("Memuat $progress / 40 Fungsi...", color = NeonGreen, fontSize = 13.sp)
            Text("Dev: IDI STORE WDA KEECC Cirebon",
                color = WhiteSoft.copy(alpha = 0.5f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun RobotKEECC(scale: Float) {
    Canvas(Modifier.size(160.dp)) {
        val w = size.width; val h = size.height
        val green = NeonGreen

        // Antenna
        drawLine(green, Offset(w * 0.5f, h * 0.12f), Offset(w * 0.5f, h * 0.28f), 5f, StrokeCap.Round)
        drawCircle(green, 8f * scale, Offset(w * 0.5f, h * 0.08f))

        // Head
        drawRoundRect(
            color = green,
            topLeft = Offset(w * 0.15f, h * 0.28f),
            size = Size(w * 0.7f, h * 0.42f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f, 20f),
            style = Stroke(width = 5f)
        )

        // Eyes (neon glow)
        drawCircle(green, 9f * scale, Offset(w * 0.33f, h * 0.47f))
        drawCircle(green, 9f * scale, Offset(w * 0.67f, h * 0.47f))

        // Mouth
        drawLine(green, Offset(w * 0.35f, h * 0.60f), Offset(w * 0.65f, h * 0.60f), 5f, StrokeCap.Round)

        // Body
        drawRoundRect(
            color = green,
            topLeft = Offset(w * 0.22f, h * 0.74f),
            size = Size(w * 0.56f, h * 0.20f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f),
            style = Stroke(width = 5f)
        )
    }
}